///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <ranges>


// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/





/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for loading the textures into memory
 *  for the 3D scene.
 ***********************************************************/

void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// load the texture images for the scene to run a test of the texture mapping
	bReturn = CreateGLTexture("Textures/wood_planks_seamless.jpg", "floorTexture");

	bReturn = CreateGLTexture("Textures/metal_blue_seamless.jpg", "wallTexture");


	//mountain bike textures Milestone 5-4
	//using the textures from the "Textures" folder provided in the announcement
	// load the texture images for the mountain bike
	bReturn = CreateGLTexture("Textures/stone_light_seamless.jpg", "mframeTexture"); // using a gray texture for the mountain bike frame




	
	bReturn = CreateGLTexture("Textures/wood_black_seamless.jpg", "tireTexture"); // using a black texture for the mountain bike tires

	bReturn = CreateGLTexture("Textures/metal_pattern_seamless.jpg", "metalTexture"); // using a metal texture for the mountain bike metal parts

	bReturn = CreateGLTexture("Textures/plastic_dark_seamless.jpg", "mseatTexture"); // using a dark grey texture for the mountain bike seat
	
	bReturn = CreateGLTexture("Textures/plastic_dark_seamless.jpg", "mpedalTexture"); // using a dark grey texture for the mountain bike pedals

	//many of the SRAM and Shimano metal and plastic parts share pedal black paint.
	
	bReturn = CreateGLTexture("Textures/wood_black_seamless.jpg", "mhandlebarTexture"); // using a black texture for the mountain bike handlebars

	bReturn = CreateGLTexture("Textures/metal_galvanized_seamless.jpg", "mchainTexture"); // using a metal texture for the mountain bike chain

	bReturn = CreateGLTexture("Textures/Logo.png", "bikeLogoOverlay"); // using a metal texture for the mountain bike brakes

	//road bike textures ....
	bReturn = CreateGLTexture("Textures/paper_textured_seamless.jpg", "rframeTexture");	

	bReturn = CreateGLTexture("Textures/metal_blue_seamless.jpg", "rpedalTexture");

	bReturn = CreateGLTexture("Textures/plastic_pattern_seamless.jpg", "rseatTexture");


	//Gator bag texture
	bReturn = CreateGLTexture("Textures/rubber_nubs_seamless.jpg", "bagbodyTexture");



	//Vacuumm 
	bReturn = CreateGLTexture("Textures/rubber_circles_seamless.jpg", "vacuumbodyTexture");




	bReturn = CreateGLTexture("Textures/leather_tan_seamless.jpg", "vacuumhandleTexture");



	// Bind all textures to OpenGL slots
	BindGLTextures();
}
// Setting an Overlay texture method for the bike logo overlay on the mountain bike frame.

void SceneManager::SetShaderTextureOverlay(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		if (textureTag.size() > 0)
		{
			m_pShaderManager->setIntValue("useTextureOverlay", true);

			int textureID = -1;
			textureID = FindTextureSlot(textureTag);
			m_pShaderManager->setSampler2DValue("textureOverlay", textureID);
		}
		else
		{
			m_pShaderManager->setIntValue("useTextureOverlay", false);
		}
	}
}



/**********************************************************
*LoadScene Lighting                                       *
* This method is used for defining the lighting for the   *
* scene.                                                  *
***********************************************************/

void SceneManager::LoadSceneLighting()
{
	// set the lighting values for the scene
	m_pShaderManager->setBoolValue(g_UseLightingName, true); // enable lighting in the shader

	//This scene should emulate the lighting of a room with single LED semi-warm light
	// directional light: main light source simulates room lighting outside the scene
		// directional light to emulate Room cealing light coming into scene
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.3f, -1.0f, -0.2f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.02f, 0.02f, 0.02f); // Set ambient light low
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 1.0f, 0.95f, 0.85f); // set diffuse light high to emulate direct lighting
	m_pShaderManager->setVec3Value("directionalLight.specular", 1.0f, 1.0f, 0.9f); // set spectacular highlighs
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);


	// point light 1
	m_pShaderManager->setVec3Value("pointLights[0].position", 0.0f, 10.0f, 5.0f); // 
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.15f, 0.15f, 0.15f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.5f, 0.5f, 0.5f);

	// the point light specular highlights
	m_pShaderManager->setVec3Value("pointLights[0].specular", 1.0f, 1.0f, 1.0f); // will maintain reflectiveness across scene

	
	

	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);


	//point light 2 
	m_pShaderManager->setVec3Value("pointLights[1].position", -3.0f, 6.0f, 2.0f); // light on top the Gator bag
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.10f, 0.08f, 0.05f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.9f, 0.7f, 0.4f);   // warm color
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.10f, 0.09f, 0.07f);

	

	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// point light 3 — cool fill light 
	m_pShaderManager->setVec3Value("pointLights[2].position", 4.0f, 4.0f, -2.0f); // light on top the vac
	m_pShaderManager->setVec3Value("pointLights[2].ambient", 0.05f, 0.05f, 0.10f);
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", 0.4f, 0.4f, 0.9f);   // cool blue tint
	m_pShaderManager->setVec3Value("pointLights[2].specular", 0.06f, 0.06f, 0.10f);



	m_pShaderManager->setBoolValue("pointLights[2].bActive", true);
	



	
}



/***********************************************************
*LoadSceneMaterials()
*
* This method is used for defining the materials for the
* objects in the 3D scene.
* **********************************************************/


void SceneManager::LoadSceneMaterials()

{


	// define the materials for the objects in the scene


	OBJECT_MATERIAL material;
// define a material for the floor plane
	material.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	material.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	material.shininess = 32.0f;
	material.tag = "floorMaterial";
	m_objectMaterials.push_back(material);
	// define a material for the wall plane
	material.diffuseColor = glm::vec3(0.9f, 0.9f, 0.9f);
	material.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	material.shininess = 16.0f;
	material.tag = "wallMaterial";
	m_objectMaterials.push_back(material);



	OBJECT_MATERIAL mountainbikeMaterial;
	
	// define a material for the mountain bike frame
	mountainbikeMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	mountainbikeMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	mountainbikeMaterial.shininess = 64.0f;
	mountainbikeMaterial.tag = "mframeMaterial";
	m_objectMaterials.push_back(mountainbikeMaterial);
	// define a material for the mountain bike tires
	mountainbikeMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	mountainbikeMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	mountainbikeMaterial.shininess = 32.0f;
	mountainbikeMaterial.tag = "tireMaterial";
	m_objectMaterials.push_back(mountainbikeMaterial);
	// define a material for the metal parts
	mountainbikeMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	mountainbikeMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.9f);
	mountainbikeMaterial.shininess = 512.0f;
	mountainbikeMaterial.tag = "metalMaterial";
	m_objectMaterials.push_back(mountainbikeMaterial);
	// define a material for the mountain bike seat
	mountainbikeMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	mountainbikeMaterial.specularColor = glm::vec3(0.3f, 0.2f, 0.3f);
	mountainbikeMaterial.shininess = 32.0f;
	mountainbikeMaterial.tag = "mseatMaterial";
	m_objectMaterials.push_back(mountainbikeMaterial);
	// define a material for the mountain bike pedals
	mountainbikeMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	mountainbikeMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	mountainbikeMaterial.shininess = 64.0f;
	mountainbikeMaterial.tag = "mpedalMaterial";
	m_objectMaterials.push_back(mountainbikeMaterial);
	// define a material for the mountain bike handlebars
	mountainbikeMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f);
	mountainbikeMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	mountainbikeMaterial.shininess = 45.0f;
	mountainbikeMaterial.tag = "mhandlebarMaterial";
	m_objectMaterials.push_back(mountainbikeMaterial);
	// define a material for the mountain bike chain
	mountainbikeMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	mountainbikeMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	mountainbikeMaterial.shininess = 65.0f;
	mountainbikeMaterial.tag = "mchainMaterial";
	m_objectMaterials.push_back(mountainbikeMaterial);

	

	OBJECT_MATERIAL roadbikeMaterial;
	// define a material for the road bike frame
	roadbikeMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	roadbikeMaterial.specularColor = glm::vec3(1.0f, 0.9f, 1.0f);
	roadbikeMaterial.shininess = 256.0f;
	roadbikeMaterial.tag = "rframeMaterial";
	m_objectMaterials.push_back(roadbikeMaterial);

	// define a material for the road bike seat
	roadbikeMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f); //
	roadbikeMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	roadbikeMaterial.shininess = 34.0f;
	roadbikeMaterial.tag = "rseatMaterial";
	m_objectMaterials.push_back(roadbikeMaterial);

	// define a material for the road bike pedals
	roadbikeMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	roadbikeMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	roadbikeMaterial.shininess = 64.0f;
	roadbikeMaterial.tag = "rpedalMaterial";
	m_objectMaterials.push_back(roadbikeMaterial);
	



	OBJECT_MATERIAL vacuumMaterial;
	// define a material for the black vacuum
	vacuumMaterial.diffuseColor = glm::vec3(0.1f, 0.1f, 0.1f); // dark gray color
	vacuumMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	vacuumMaterial.shininess = 6.0f;
	vacuumMaterial.tag = "vacuumMaterial";
	m_objectMaterials.push_back(vacuumMaterial);
	
	OBJECT_MATERIAL gatorCaseMaterial;
	// define a material for the Gator softshell guitar case
	gatorCaseMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f); // dark gray color
	gatorCaseMaterial.specularColor = glm::vec3(0.06f, 0.06f, 0.06f); // light gray specular color
	gatorCaseMaterial.shininess = 0.01f;
	gatorCaseMaterial.tag = "gatorCaseMaterial";
	m_objectMaterials.push_back(gatorCaseMaterial);

}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

	//load textures
	LoadSceneTextures();
	//loads Lighting
	LoadSceneLighting();

	// load the materials for the 3D scene
	LoadSceneMaterials();
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();

	// load the textures into memory for the 3D scene
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadPyramid3Mesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{	

	
	
	//Floor plane
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(10.0f, 1.0f, 6.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 2.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("floorTexture");  // set the texture for the mesh

	SetShaderMaterial("floorMaterial");  // set the material for the mesh

	SetTextureUVScale(10.0f, 10.0f); // set the UV scale for the texture mapping

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	//Wall Plane (vertical)
	scaleXYZ = glm::vec3(10.0f, 1.0f, 5.0f);   // width, height, thickness
	positionXYZ = glm::vec3(0.0f, 5.0f, -3.5f); // centered behind bikes
	XrotationDegrees = 90.0f;                   // rotate plane upright
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wallTexture");  // set the texture for the mesh
	SetShaderMaterial("wallMaterial");  // set the material for the mesh
	SetTextureUVScale(10.0f, 5.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/


	/****************************************************
	*MOUNTAIN BIKE                                      *
	****************************************************/
	float bikeHangX = 3.0f;
	
	float bikeHangZ = -1.5f;

	/**********************************************
	*  BIKE WHEELS								  *
	***********************************************/

	// FRONT WHEEL
	scaleXYZ = glm::vec3(1.5f, 0.5f, 1.5f);
	positionXYZ = glm::vec3(bikeHangX, 8.0f, bikeHangZ);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("tireTexture");  // set the texture for the mesh
	SetShaderMaterial("tireMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 1.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawTorusMesh();

	//FRONT HUB
	scaleXYZ = glm::vec3(0.1f, 0.5f, 0.5f);
	positionXYZ = glm::vec3(bikeHangX, 8.0f, bikeHangZ);
	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderTexture("tireTexture");  // set the texture for the mesh- tire texture looked better than metal texture for the hubs
	SetShaderMaterial("tireMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 1.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawSphereMesh();

	// REAR HUB
	scaleXYZ = glm::vec3(0.1f, 0.5f, 0.5f);
	positionXYZ = glm::vec3(bikeHangX, 2.0f, bikeHangZ);
	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderTexture("tireTexture");  // set the texture for the mesh
	SetShaderMaterial("tireMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 1.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawSphereMesh();

	//CASSETTE
	scaleXYZ = glm::vec3(0.6f, 0.4f, 0.5f);
	positionXYZ = glm::vec3(bikeHangX + 0.2f, 2.0f, bikeHangZ);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("metalTexture");  // set the texture for the mesh
	SetShaderMaterial("metalMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 3.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawConeMesh();

	// REAR WHEEL
	scaleXYZ = glm::vec3(1.5f, 0.5f, 1.5f);
	positionXYZ = glm::vec3(bikeHangX, 2.0f, bikeHangZ);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("tireTexture");  // set the texture for the mesh
	SetShaderMaterial("tireMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 1.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawTorusMesh();


	/**********************************************
	*  BIKE FRAME								  *
	***********************************************/

	// SEAT TUBE
	scaleXYZ = glm::vec3(1.45f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX, 4.15f, bikeHangZ + 0.8f);
	SetTransformations(scaleXYZ, 90, 67, 90, positionXYZ);
	SetShaderTexture("mframeTexture");  // set the texture for the mesh
	SetShaderMaterial("mframeMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();


	// TOP TUBE
	scaleXYZ = glm::vec3(1.24f, 0.14f, 0.21f);
	positionXYZ = glm::vec3(bikeHangX, 5.15f, bikeHangZ + 1.55f);
	SetTransformations(scaleXYZ, 90, -15, 90, positionXYZ);
	SetTransformations(scaleXYZ, 90, -15, 90, positionXYZ);
	SetShaderTexture("mframeTexture");
	SetShaderMaterial("mframeMaterial");
	SetTextureUVScale(6.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();
	
	

	// DOWN TUBE
	scaleXYZ = glm::vec3(1.4f, 0.15f, 0.15f);
	positionXYZ = glm::vec3(bikeHangX, 5.5f, bikeHangZ + 0.75f);
	SetTransformations(scaleXYZ, 90, 123, 90, positionXYZ);
	SetShaderTexture("mframeTexture");  // set the texture for the mesh
	SetShaderMaterial("mframeMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();

	// CHAINSTAYS

	// CHAINSTAY Right
	scaleXYZ = glm::vec3(1.3f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX + 0.1f, 3.5f, bikeHangZ - 0.3f);
	SetTransformations(scaleXYZ, 90, 12, 90, positionXYZ);
	SetShaderTexture("mframeTexture");  // set the texture for the mesh
	SetShaderMaterial("mframeMaterial");  // set the material for the mesh
	SetTextureUVScale(4.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();

	// CHAINSTAY Left
	scaleXYZ = glm::vec3(1.3f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX - 0.1f, 3.5f, bikeHangZ - 0.3f);
	SetTransformations(scaleXYZ, 90, 12, 90, positionXYZ);
	SetShaderTexture("mframeTexture");  // set the texture for the mesh
	SetShaderMaterial("mframeMaterial");  // set the material for the mesh
	SetTextureUVScale(4.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();



	// SEATSTAYS

	// SEATSTAY Right
	scaleXYZ = glm::vec3(1.0f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX + 0.1f, 3.17f, bikeHangZ + 0.8f);
	SetTransformations(scaleXYZ, 90, 145, 90, positionXYZ);
	SetShaderTexture("mframeTexture");  // set the texture for the mesh
	SetShaderMaterial("mframeMaterial");  // set the material for the mesh
	SetTextureUVScale(4.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();
	// SEATSTAY Left
	scaleXYZ = glm::vec3(1.0f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX - 0.1f, 3.17f, bikeHangZ + 0.8f);
	SetTransformations(scaleXYZ, 90, 145, 90, positionXYZ);
	SetShaderTexture("mframeTexture");  // set the texture for the mesh
	SetShaderMaterial("mframeMaterial");  // set the material for the mesh
	SetTextureUVScale(4.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();


	//FORKS 

	//FORK STEM
	scaleXYZ = glm::vec3(0.08f, 0.4f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX - 0.2f, 6.3f, bikeHangZ + 1.70f);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("mhandlebarTexture");  // set the texture for the mesh
	SetShaderMaterial("mhandlebarMaterial");  // set the material for the mesh
	SetTextureUVScale(4.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();

	
	// FORK Right
	scaleXYZ = glm::vec3(1.15f, 0.13f, 0.12f);
	positionXYZ = glm::vec3(bikeHangX + 0.2f, 7.0f, bikeHangZ + 1.0f);
	SetTransformations(scaleXYZ, 90, 45, 90, positionXYZ);
	SetShaderTexture("mhandlebarTexture");  // set the texture for the mesh
	SetShaderMaterial("mhandlebarMaterial");  // set the material for the mesh
	SetTextureUVScale(4.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawTaperedCylinderMesh();

	// FORK Left
	scaleXYZ = glm::vec3(1.15f, 0.13f, 0.12f);
	positionXYZ = glm::vec3(bikeHangX - 0.2f, 7.0f, bikeHangZ + 1.0f);
	SetTransformations(scaleXYZ, 90, 45, 90, positionXYZ);
	SetShaderTexture("mhandlebarTexture");  // set the texture for the mesh
	SetShaderMaterial("mhandlebarMaterial");  // set the material for the mesh
	SetTextureUVScale(4.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawTaperedCylinderMesh();

	/**********************************************
	*  HANDLEBARS AND FORKs						  *
	***********************************************/
	
	//HANDLEBAR STEM
	scaleXYZ = glm::vec3(0.08f, 0.4f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX, 6.17f, bikeHangZ + 2.36f);
	SetTransformations(scaleXYZ, 90, 90, 90, positionXYZ);
	SetShaderTexture("mhandlebarTexture");  // set the texture for the mesh
	SetShaderMaterial("mhandlebarMaterial");  // set the material for the mesh
	SetTextureUVScale(2.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();

	
	// HANDLEBAR
	scaleXYZ = glm::vec3(0.2f, 3.0f, 0.1f);
	positionXYZ = glm::vec3(1.5f, 6.57f, bikeHangZ + 2.46f);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("mhandlebarTexture");  // set the texture for the mesh
	SetShaderMaterial("mhandlebarMaterial");  // set the material for the mesh
	SetTextureUVScale(4.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();

	// HEADTUBE
	scaleXYZ = glm::vec3(0.1f, 0.6f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX, 6.27f, bikeHangZ + 1.8f);
	SetTransformations(scaleXYZ, 90, 0, 90, positionXYZ);
	SetShaderTexture("mframeTexture");  // set the texture for the mesh
	SetShaderMaterial("mframeMaterial");  // set the material for the mesh
	SetTextureUVScale(3.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();


	/***************************************************
	*Central crankset and chainring point of reference
	****************************************************/
	// CRANKSET

	scaleXYZ = glm::vec3(0.75f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX, 4.8f, bikeHangZ - 0.5f);
	SetTransformations(scaleXYZ, 90, 135, 0, positionXYZ);
	SetShaderTexture("mpedalTexture");  // set the texture for the mesh
	SetShaderMaterial("mpedalMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 1.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();

	//BOTTOM BRACKET
	scaleXYZ = glm::vec3(0.15f, 0.15f, 0.15f);
	positionXYZ = glm::vec3(bikeHangX, 4.8f, bikeHangZ - 0.5f);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("mpedalTexture");  // set the texture for the mesh
	SetShaderMaterial("mpedalMaterial");  // set the material for the mesh
	SetTextureUVScale(2.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();

	// CHAINRING

	
	scaleXYZ = glm::vec3(0.3f, 0.3f, 0.3f);
	positionXYZ = glm::vec3(bikeHangX + 0.26f, 4.8f, bikeHangZ - 0.5f);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("mpedalTexture");  // set the texture for the mesh
	SetShaderMaterial("mpedalMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 1.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawTorusMesh();
	/*******************************************************/

	// CHAIN UPPER HALF
	scaleXYZ = glm::vec3(1.6f, 0.04f, 0.05f);
	positionXYZ = glm::vec3(bikeHangX + 0.26f, 3.4f, bikeHangZ);
	SetTransformations(scaleXYZ, 90, 5, 90, positionXYZ);
	SetShaderTexture("mchainTexture");  // set the texture for the mesh
	SetShaderMaterial("mchainMaterial");  // set the material for the mesh
	SetTextureUVScale(2.0f, 1.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawTaperedCylinderMesh();

	// CHAIN LOWER HALF 
	scaleXYZ = glm::vec3(1.6f, 0.04f, 0.05f);
	positionXYZ = glm::vec3(bikeHangX + 0.26f, 3.4f, bikeHangZ - 1.0f);
	SetTransformations(scaleXYZ, 90, -7, 90, positionXYZ);
	SetShaderTexture("mchainTexture");  // set the texture for the mesh
	SetShaderMaterial("mchainMaterial");  // set the material for the mesh
	SetTextureUVScale(2.0f, 1.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawTaperedCylinderMesh();

	// REAR DERAILLEUR
	scaleXYZ = glm::vec3(0.2f, 0.5f, 0.2f);
	positionXYZ = glm::vec3(bikeHangX + 0.26f, 1.8f, bikeHangZ - 0.8f);
	SetTransformations(scaleXYZ, 90, -27, 90, positionXYZ);
	SetShaderTexture("mpedalTexture");  // set the texture for the mesh
	SetShaderMaterial("mpedalMaterial");  // set the material for the mesh
	SetTextureUVScale(6.0f, 1.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawBoxMesh();

	// SEATPOST
	scaleXYZ = glm::vec3(0.5f, 0.08f, 0.1f);
	positionXYZ = glm::vec3(bikeHangX, 3.4f, bikeHangZ + 2.5f);
	SetTransformations(scaleXYZ, 90, 67, 90, positionXYZ);
	SetShaderTexture("mseatTexture");  // set the texture for the mesh
	SetShaderMaterial("mseatMaterial");  // set the material for the mesh
	SetTextureUVScale(2.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawCylinderMesh();

	// SADDLE
	scaleXYZ = glm::vec3(1.0f, 0.3f, 0.5f);
	positionXYZ = glm::vec3(bikeHangX, 2.8f, bikeHangZ + 2.7f);
	SetTransformations(scaleXYZ, 90, 0, 90, positionXYZ);
	SetShaderTexture("mseatTexture");  // set the texture for the mesh
	SetShaderMaterial("mseatMaterial");  // set the material for the mesh
	SetTextureUVScale(2.0f, 2.0f); // set the UV scale for the texture mapping
	m_basicMeshes->DrawTaperedCylinderMesh();

	//-------------------------------------------------------------------------

	/****************************************************/
	// ROAD BIKE
	/****************************************************/
	float roadbikeHangX = -1.0f;
	

	/**********************
	*   WHEELS & HUBS     *
	**********************/

	// FRONT WHEEL
	scaleXYZ = glm::vec3(1.5f, 0.3f, 1.5f);
	positionXYZ = glm::vec3(roadbikeHangX, 7.5f, bikeHangZ);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("tireTexture");
	SetShaderMaterial("tireMaterial");
	SetTextureUVScale(6.0f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	// FRONT HUB
	scaleXYZ = glm::vec3(0.1f, 0.5f, 0.5f);
	positionXYZ = glm::vec3(roadbikeHangX, 7.5f, bikeHangZ);
	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderTexture("tireTexture");
	SetShaderMaterial("tireMaterial");
	SetTextureUVScale(6.0f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// REAR HUB
	scaleXYZ = glm::vec3(0.1f, 0.5f, 0.5f);
	positionXYZ = glm::vec3(roadbikeHangX, 2.0f, bikeHangZ);
	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderTexture("tireTexture");
	SetShaderMaterial("tireMaterial");
	SetTextureUVScale(6.0f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// CASSETTE
	scaleXYZ = glm::vec3(0.6f, 0.4f, 0.5f);
	positionXYZ = glm::vec3(roadbikeHangX + 0.2f, 2.0f, bikeHangZ);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("metalTexture");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(6.0f, 3.0f);
	m_basicMeshes->DrawConeMesh();

	// REAR WHEEL
	scaleXYZ = glm::vec3(1.5f, 0.3f, 1.5f);
	positionXYZ = glm::vec3(roadbikeHangX, 2.0f, bikeHangZ);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("tireTexture");
	SetShaderMaterial("tireMaterial");
	SetTextureUVScale(6.0f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	/**********************/
	/*   ROAD FRAME       */
	/**********************/

	// SEAT TUBE (steeper)
	scaleXYZ = glm::vec3(1.45f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX, 3.8f, bikeHangZ + 0.8f);
	SetTransformations(scaleXYZ, 90, 72, 90, positionXYZ);
	SetShaderTexture("rframeTexture");
	SetShaderMaterial("rframeMaterial");
	SetTextureUVScale(4.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// TOP TUBE (longer, flatter)
	scaleXYZ = glm::vec3(1.35f, 0.14f, 0.21f);
	positionXYZ = glm::vec3(roadbikeHangX, 4.9f, bikeHangZ + 1.55f);
	SetTransformations(scaleXYZ, 90, -5, 90, positionXYZ);
	SetShaderTexture("rframeTexture");
	SetShaderMaterial("rframeMaterial");
	SetTextureUVScale(4.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// DOWN TUBE (road angle)
	scaleXYZ = glm::vec3(1.45f, 0.15f, 0.15f);
	positionXYZ = glm::vec3(roadbikeHangX, 5.4f, bikeHangZ + 0.66f);
	SetTransformations(scaleXYZ, 90, 125, 90, positionXYZ);
	SetShaderTexture("rframeTexture");
	SetShaderMaterial("rframeMaterial");
	SetTextureUVScale(4.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// CHAINSTAYS (shorter)
	scaleXYZ = glm::vec3(1.2f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX, 3.3f, bikeHangZ - 0.3f);
	SetTransformations(scaleXYZ, 90, 18, 90, positionXYZ);
	SetShaderTexture("rframeTexture");
	SetShaderMaterial("rframeMaterial");
	SetTextureUVScale(4.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// SEATSTAYS (straighter)
	scaleXYZ = glm::vec3(1.1f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX, 2.8f, bikeHangZ + 0.8f);
	SetTransformations(scaleXYZ, 90, 137, 90, positionXYZ);
	SetShaderTexture("rframeTexture");
	SetShaderMaterial("rframeMaterial");
	SetTextureUVScale(4.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	/**********************/
	/*   ROAD FORK        */
	/**********************/

	// FORK STEM (road geometry)
	scaleXYZ = glm::vec3(0.08f, 0.4f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX - 0.2f, 6.7f, bikeHangZ + 1.70f);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("mhandlebarTexture");
	SetShaderMaterial("mhandlebarMaterial");
	SetTextureUVScale(3.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// FORK BLADES (straighter)
	scaleXYZ = glm::vec3(1.15f, 0.13f, 0.12f);
	positionXYZ = glm::vec3(roadbikeHangX + 0.2f, 7.3f, bikeHangZ + 1.0f);
	SetTransformations(scaleXYZ, 90, 35, 90, positionXYZ);
	SetShaderTexture("mhandlebarTexture");
	SetShaderMaterial("mhandlebarMaterial");
	SetTextureUVScale(3.0f, 2.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();
	
	// FORK LEFT
	scaleXYZ = glm::vec3(1.15f, 0.13f, 0.12f);
	positionXYZ = glm::vec3(roadbikeHangX - 0.2f, 7.3f, bikeHangZ + 1.0f);
	SetTransformations(scaleXYZ, 90, 35, 90, positionXYZ);
	SetShaderTexture("mhandlebarTexture");
	SetShaderMaterial("mhandlebarMaterial");
	SetTextureUVScale(3.0f, 2.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();

	/**********************/
	/*   ROAD HANDLEBARS  */
	/**********************/

	// STEM
	scaleXYZ = glm::vec3(0.08f, 0.4f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX, 6.33f, bikeHangZ + 1.97f);
	SetTransformations(scaleXYZ, 90, 90, 90, positionXYZ);
	SetShaderTexture("mhandlebarTexture");
	SetShaderMaterial("mhandlebarMaterial");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// HANDLEBAR
	scaleXYZ = glm::vec3(0.2f, 2.0f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX - 1.0f, 6.7f, bikeHangZ + 1.97f);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("mhandlebarTexture");
	SetShaderMaterial("mhandlebarMaterial");
	SetTextureUVScale(4.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// AERO BARS LEFT
	scaleXYZ = glm::vec3(0.2f, 1.0f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX + 1.15f, 6.5f, bikeHangZ + 1.86f);
	SetTransformations(scaleXYZ, 90, 60, 139, positionXYZ);
	SetShaderTexture("mhandlebarTexture");
	SetShaderMaterial("mhandlebarMaterial");
	SetTextureUVScale(4.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// AERO BARS LEFT
	scaleXYZ = glm::vec3(0.2f, 1.0f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX -1.1f, 6.5f, bikeHangZ + 1.86f);
	SetTransformations(scaleXYZ, 90, 60, 49, positionXYZ);
	SetShaderTexture("mhandlebarTexture");
	SetShaderMaterial("mhandlebarMaterial");
	SetTextureUVScale(4.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// HEADTUBE
	scaleXYZ = glm::vec3(0.1f, 0.5f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX, 6.3f, bikeHangZ + 1.5f);
	SetTransformations(scaleXYZ, 90, 0, 90, positionXYZ);
	SetShaderTexture("rframeTexture");  
	SetShaderMaterial("rframeMaterial");  
	SetTextureUVScale(3.0f, 2.0f); 
	m_basicMeshes->DrawCylinderMesh();

	/**********************/
	/*   CRANKSET         */
	/**********************/

	// CRANK ARM
	scaleXYZ = glm::vec3(0.75f, 0.1f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX, 4.5f, bikeHangZ - 0.5f);
	SetTransformations(scaleXYZ, 90, 135, 0, positionXYZ);
	SetShaderTexture("rpedalTexture");
	SetShaderMaterial("rpedalMaterial");
	SetTextureUVScale(6.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// BOTTOM BRACKET
	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(roadbikeHangX + 0.006f, 4.5f, bikeHangZ - 0.5f);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("rpedalTexture");
	SetShaderMaterial("rpedalMaterial");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// CHAINRING
	scaleXYZ = glm::vec3(0.3f, 0.3f, 0.3f);
	positionXYZ = glm::vec3(roadbikeHangX + 0.20f, 4.5f, bikeHangZ - 0.5f);
	SetTransformations(scaleXYZ, 90, 90, 0, positionXYZ);
	SetShaderTexture("rpedalTexture");
	SetShaderMaterial("rpedalMaterial");
	SetTextureUVScale(6.0f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	/**********************/
	/*   CHAIN            */
	/**********************/

	// UPPER CHAIN
	scaleXYZ = glm::vec3(1.2f, 0.04f, 0.05f);
	positionXYZ = glm::vec3(roadbikeHangX + 0.26f, 3.5f, bikeHangZ);
	SetTransformations(scaleXYZ, 90, 9, 90, positionXYZ);
	SetShaderTexture("mchainTexture");
	SetShaderMaterial("mchainMaterial");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();

	// LOWER CHAIN
	scaleXYZ = glm::vec3(1.3f, 0.04f, 0.05f);
	positionXYZ = glm::vec3(roadbikeHangX + 0.26f, 3.3f, bikeHangZ - 0.95f);
	SetTransformations(scaleXYZ, 90, -4, 90, positionXYZ);
	SetShaderTexture("mchainTexture");
	SetShaderMaterial("mchainMaterial");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();

	/**********************/
	/*   REAR DERAILLEUR  */
	/**********************/
	scaleXYZ = glm::vec3(0.2f, 0.5f, 0.2f);
	positionXYZ = glm::vec3(roadbikeHangX + 0.26f, 1.8f, bikeHangZ - 0.8f);
	SetTransformations(scaleXYZ, 90, -27, 90, positionXYZ);
	SetShaderTexture("rpedalTexture");
	SetShaderMaterial("rpedalMaterial");
	SetTextureUVScale(6.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	/**********************/
	/*   SEATPOST & SADDLE*/
	/**********************/

	// SEATPOST (higher)
	scaleXYZ = glm::vec3(0.5f, 0.08f, 0.1f);
	positionXYZ = glm::vec3(roadbikeHangX, 3.23f, bikeHangZ + 2.5f);
	SetTransformations(scaleXYZ, 90, 67, 90, positionXYZ);
	SetShaderTexture("rseatTexture");
	SetShaderMaterial("rseatMaterial");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// SADDLE (higher)
	scaleXYZ = glm::vec3(1.0f, 0.3f, 0.5f);
	positionXYZ = glm::vec3(roadbikeHangX, 3.5f, bikeHangZ + 2.7f);
	SetTransformations(scaleXYZ, 90, 0, 90, positionXYZ);
	SetShaderTexture("rseatTexture");
	SetShaderMaterial("rseatMaterial");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();





// ---------------------------------------------------------
// VACUUM
// ---------------------------------------------------------

// VACUUM BODY
scaleXYZ = glm::vec3(1.0f, 1.5f, 1.0f);
positionXYZ = glm::vec3(-4.0f, 0.0f, 0.0f);
SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
SetShaderTexture("vacuumbodyTexture");
SetShaderMaterial("vacuumMaterial");
SetTextureUVScale(4.0f, 4.0f);

m_basicMeshes->DrawCylinderMesh();

// VACUUM MOTOR
scaleXYZ = glm::vec3(1.0f, 0.5f, 1.0f);
positionXYZ = glm::vec3(-4.0f, 1.3f, 0.0f);
SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
SetShaderTexture("vacuumbodyTexture");
SetShaderMaterial("vacuumMaterial");
SetTextureUVScale(2.0f, 2.0f);
m_basicMeshes->DrawSphereMesh();

// VACUUM INTAKE
scaleXYZ = glm::vec3(0.3f, 0.3f, 0.3f);
positionXYZ = glm::vec3(-4.0f, 1.0f, 1.0f);
SetTransformations(scaleXYZ, 90, 0, 0, positionXYZ);
SetShaderTexture("vacuumbodyTexture");
SetShaderMaterial("vacuumMaterial");
SetTextureUVScale(4.0f, 4.0f);

m_basicMeshes->DrawTaperedCylinderMesh();

//VACUUM OUTTAKE
scaleXYZ = glm::vec3(0.4f, 0.3f, 0.3f);
positionXYZ = glm::vec3(-4.2f, 1.01f, -1.2f);
SetTransformations(scaleXYZ, 90, 0, 0, positionXYZ);

SetShaderTexture("vacuumbodyTexture");
SetShaderMaterial("vacuumMaterial");
SetTextureUVScale(2.0f, 2.0f);

m_basicMeshes->DrawTaperedCylinderMesh();

//VACUUM HANDLE
scaleXYZ = glm::vec3(0.4f, 0.2f, 0.3f);
positionXYZ = glm::vec3(-4.0f, 1.6f, 0.0f);
SetTransformations(scaleXYZ, 90, 0, 0, positionXYZ);
SetShaderTexture("vacuumhandleTexture");
SetShaderMaterial("vacuumMaterial");
SetTextureUVScale(3.0f, 3.0f);

m_basicMeshes->DrawTorusMesh();


// ---------------------------------------------------------
// GATOR SOFT-SHELL GUITAR BAG
// ---------------------------------------------------------

// GATOR BAG — COMPLEX TEXTURING (BOX)
scaleXYZ = glm::vec3(1.45f, 3.2f, 0.36f);
positionXYZ = glm::vec3(6.0f, 2.0f, -2.5f);
SetTransformations(scaleXYZ, 0, 0, -10.0f, positionXYZ);

//Cube planar texture

// BACK
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_back);

// BOTTOM
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_bottom);

// LEFT
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_left);

// RIGHT
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_right);

// TOP
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_top);

// FRONT
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_front);

// BAG NECK
scaleXYZ = glm::vec3(0.7f, 2.3f, 0.3f);
positionXYZ = glm::vec3(6.25f, 3.5f, -2.5f);
SetTransformations(scaleXYZ, 0, 0, -10.0f, positionXYZ);
SetShaderColor(0.05f, 0.05f, 0.05f, 1);
// BACK
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawTaperedCylinderMesh(ShapeMeshes::box_back);

// BOTTOM
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawTaperedCylinderMesh(ShapeMeshes::box_bottom);

// LEFT
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawTaperedCylinderMesh(ShapeMeshes::box_left);

// RIGHT
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawTaperedCylinderMesh(ShapeMeshes::box_right);

// TOP
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawTaperedCylinderMesh(ShapeMeshes::box_top);

// FRONT
SetShaderTexture("bagbodyTexture");
SetShaderMaterial("gatorCaseMaterial");
m_basicMeshes->DrawTaperedCylinderMesh(ShapeMeshes::box_front);


}
